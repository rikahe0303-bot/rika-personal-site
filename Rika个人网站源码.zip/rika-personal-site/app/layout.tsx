import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Rika · 慢热，但对世界充满热情",
  description: "嗨，我是 Rika，来自云南，现居西安。这里有我的个人说明书、旅行与生活切片。欢迎走进我的小世界。",
  icons: { icon: `${process.env.NEXT_PUBLIC_BASE_PATH || ""}/favicon.svg`, shortcut: `${process.env.NEXT_PUBLIC_BASE_PATH || ""}/favicon.svg` },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
