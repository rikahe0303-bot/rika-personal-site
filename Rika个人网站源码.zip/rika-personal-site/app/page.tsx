"use client";

import { useRef, useState } from "react";
import { ArrowUpRight, ArrowDown, MapPin, Copy, Check, X, ChevronLeft, ChevronRight, Menu } from "lucide-react";

const assetPath = (path: string) => `${process.env.NEXT_PUBLIC_BASE_PATH || ""}${path}`;

const photos = [
  { src: assetPath("/photos/image3.jpeg"), title: "把日落装进口袋", category: "在路上", note: "山顶的风，和刚刚好的晚霞。" },
  { src: assetPath("/photos/image6.jpeg"), title: "假装文艺青年", category: "小日常", note: "去看展，在别人的色彩里待一会儿。" },
  { src: assetPath("/photos/image9.jpeg"), title: "和大自然亲密接触", category: "在路上", note: "出门走走，总会遇见意料之外的可爱。" },
  { src: assetPath("/photos/image11.jpeg"), title: "今天的搭子：胖虎", category: "小日常", note: "介绍一下，这是胖虎，我的干儿子。" },
  { src: assetPath("/photos/image10.jpeg"), title: "紧跟潮流，拼豆！", category: "小日常", note: "一点一点，拼出日常的小快乐。" },
];
const source = "https://my.feishu.cn/wiki/PwFMwXy47i7csPkxGR7cD1k86Pf?from=from_copylink";

export default function Home() {
  const [filter, setFilter] = useState("全部");
  const [selected, setSelected] = useState(0);
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  async function copyPhone() {
    try { await navigator.clipboard.writeText("19526880781"); setCopied(true); setCopyError(false); setTimeout(() => setCopied(false), 2500); }
    catch { setCopyError(true); }
  }
  function openPhoto(index: number) { setSelected(index); dialog.current?.showModal(); }
  const links = [["关于我", "about"], ["生活切片", "moments"], ["相处指南", "guide"]];
  return (
    <>
      <a className="skip-link" href="#main">跳至内容</a>
      <header className="site-header">
        <a className="wordmark" href="#" aria-label="Rika 首页">rika<span>✳</span></a>
        <nav aria-label="主导航" className={menuOpen ? "navigation open" : "navigation"}>
          {links.map(([label, id]) => <a key={id} href={`#${id}`} onClick={() => setMenuOpen(false)}>{label}</a>)}
        </nav>
        <a className="nav-contact" href="#contact">来打个招呼 <ArrowUpRight size={16}/></a>
        <button className="menu-button" aria-label={menuOpen ? "关闭菜单" : "打开菜单"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X/> : <Menu/>}</button>
      </header>
      <main id="main">
        <section className="hero wrap" aria-labelledby="hero-title">
          <div className="hero-copy">
            <div className="eyebrow"><span className="little-dot"/> A LITTLE SPACE, A LOT OF ME</div>
            <h1 id="hero-title"><span className="hello">嗨，我是</span><span className="hero-name">Rika<span className="name-dot">.</span><span className="hero-flower" aria-hidden="true">✳</span></span></h1>
            <h2>慢热，但对世界充满热情。</h2>
            <p className="hero-description">来自彩云之南，现居西安。<br/>一个爱旅行、爱户外，也爱宅着打游戏的 INFJ。<br/>欢迎走进我的小世界，认识一下真实的我。</p>
            <a className="button primary" href="#about">翻开我的个人说明书 <ArrowUpRight size={18}/></a>
            <div className="hero-location"><MapPin size={14}/> 中国 · 西安 <span>YUNNAN ROOTS, XI’AN DAYS</span></div>
          </div>
          <div className="hero-visual">
            <div className="photo-note">a little wild, a little soft.</div>
            <figure className="hero-photo"><img src={assetPath("/photos/image2.jpeg")} alt="Rika 站在山间草地的围栏旁" fetchPriority="high"/><figcaption><span>在山野里，做回自己。</span><span>01 / MY LITTLE WORLD</span></figcaption></figure>
            <div className="photo-stamp"><span>STAY CURIOUS</span><b>✷</b><span>保持好奇</span></div>
            <div className="photo-label">浪漫双鱼座 <span>↗</span></div>
          </div>
          <a className="scroll-note" href="#about"><ArrowDown size={15}/> 往下逛逛，慢慢认识 <span>SCROLL TO EXPLORE</span></a>
        </section>
        <div className="interest-strip" aria-label="我的关键词"><span>云南 → 西安</span><i>✳</i><span>INFJ</span><i>✳</i><span>户外充电中</span><i>✳</i><span>游戏尝鲜选手</span><i>✳</i><span>浪漫双鱼座</span><i>✳</i><span>认真生活，偶尔放空</span></div>
        <section className="about wrap section" id="about">
          <div className="section-index">01 / ABOUT ME</div>
          <div className="about-body"><div className="section-heading"><h2>比标签多一点，<br/><em>比想象有趣一点。</em></h2><span className="small-flower" aria-hidden="true">✳</span></div>
            <p>我是 Rika，也叫何丽江。毕业于西南科技大学，主修信息管理。比起一本正经的自我介绍，我更喜欢用生活里的小事，让你认识我。</p>
            <p>我有点慢热，表面波澜不惊，心里可能已经炸开了花。喜欢去不同的城市，和大自然亲密接触；也能安静地看展、拼豆，或者在游戏里探索一个新世界。</p>
            <div className="profile-facts"><div><span>从哪里来</span><strong>彩云之南 · 云南</strong></div><div><span>现在的坐标</span><strong>古都 · 西安</strong></div><div><span>我的学习经历</span><strong>西南科技大学 · 信息管理</strong></div></div>
          </div>
        </section>
        <section className="moments-section" id="moments"><div className="wrap section">
          <div className="section-top"><div><div className="section-index">02 / LITTLE MOMENTS</div><h2>生活不止一种打开方式<span className="title-dot">.</span></h2></div><p>一些出走，一些停留。<br/>都是我喜欢的日子。</p></div>
          <div className="filter-row" role="group" aria-label="照片分类">{["全部", "在路上", "小日常"].map(item => <button aria-pressed={filter===item} className={filter===item ? "filter active" : "filter"} key={item} onClick={() => setFilter(item)}>{item}{item==="全部" && <span>05</span>}</button>)}<span className="gallery-hint">点击照片，靠近一点 <ArrowUpRight size={14}/></span></div>
          <div className="photo-grid">{photos.map((photo, index) => (filter==="全部"||photo.category===filter) && <button className={`moment moment-${index}`} key={photo.src} onClick={() => openPhoto(index)} aria-label={`查看照片：${photo.title}`}><div className="moment-image"><img src={photo.src} alt={photo.title} loading="lazy"/><span className="zoom-icon"><ArrowUpRight size={20}/></span></div><div className="moment-caption"><div><span className="moment-category">{photo.category} / 0{index+1}</span><h3>{photo.title}</h3></div><ArrowUpRight size={21}/></div></button>)}</div>
          <div className="gallery-footnote"><span>照片来自我的个人说明书</span><span>COLLECT MOMENTS, NOT THINGS.</span></div>
        </div></section>
        <section className="guide wrap section" id="guide"><div className="guide-intro"><div className="section-index">03 / A LITTLE USER MANUAL</div><h2>和我相处的<br/><em>小小指南。</em></h2><p>没有复杂的使用方法。<br/>真诚一点，自在一点就好。</p><span className="handwritten">Nice to meet you :)</span></div><div className="guide-list">
          {[ ["温和，也有边界", "我很温和，也重视彼此的边界。主打一个：尊重他人命运。"], ["慢热，但很认真", "不一定是最主动的那个人，但答应的事会认真负责。熟悉以后，你会发现更多的我。"], ["是朋友，也是倾听者", "愿意听你说，也会认真给建议。知心朋友模式已开启，不过有些道理只说一遍哦。"], ["一起玩，就熟了", "约旅行、玩户外，或者一起试试新游戏。共同的快乐，是认识彼此的好方式。"] ].map(([title,text],i) => <article key={title}><span>0{i+1}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowUpRight size={18}/></article>)}
        </div></section>
        <section className="quote-section"><div className="wrap quote-inner"><span className="quote-mark">“</span><blockquote>生活给了我多少积雪，<br/>我就能遇到多少个春天。</blockquote><span className="quote-sign">写在我的个人说明书里 / Rika</span><span className="quote-spark" aria-hidden="true">✳</span></div></section>
        <section id="contact" className="contact-section"><div className="wrap"><div className="contact-top"><div><div className="section-index">04 / SAY HELLO</div><h2>故事还有很多，<br/>不如，<em>聊聊？</em></h2><p>聊旅行、聊游戏，也聊日常里那些有趣的小事。</p></div><a className="contact-arrow" href="tel:19526880781" aria-label="拨打 Rika 的电话"><ArrowUpRight strokeWidth={1} size={66}/></a></div><div className="contact-details"><div><span className="contact-label">给我打个电话</span><a className="phone" href="tel:19526880781">195 2688 0781</a></div><button className="copy-button" onClick={copyPhone}>{copied ? <Check size={16}/> : <Copy size={16}/>}<span aria-live="polite">{copied ? "号码已复制" : "复制号码"}</span></button><a className="source-link" href={source} target="_blank" rel="noreferrer">完整个人说明书 <ArrowUpRight size={17}/></a></div>{copyError && <p role="status">暂时无法自动复制，请长按或选中号码复制：19526880781</p>}<footer><a className="wordmark" href="#">rika<span>✳</span></a><span>© {new Date().getFullYear()} Rika · 认真生活，保持好奇</span><a href="#">回到顶部 ↑</a></footer></div></section>
      </main>
      <dialog ref={dialog} className="lightbox" aria-label="生活相册照片查看器" onClick={e => { if(e.target===e.currentTarget) dialog.current?.close(); }} onKeyDown={e => { if(e.key==="ArrowRight") setSelected((selected+1)%photos.length); if(e.key==="ArrowLeft") setSelected((selected+photos.length-1)%photos.length); }}><div className="lightbox-inner"><button className="lightbox-close" aria-label="关闭照片" onClick={() => dialog.current?.close()}><X/></button><img src={photos[selected].src} alt={photos[selected].title}/><div className="lightbox-caption"><div><h3>{photos[selected].title}</h3><p>{photos[selected].note}</p></div><span>{selected+1} / {photos.length}</span></div><div className="lightbox-nav"><button aria-label="上一张" onClick={() => setSelected((selected+photos.length-1)%photos.length)}><ChevronLeft/> 上一张</button><button aria-label="下一张" onClick={() => setSelected((selected+1)%photos.length)}>下一张 <ChevronRight/></button></div></div></dialog>
    </>
  );
}
