# Rika 个人网站

以个人说明书为内容来源的响应式个人网站，使用 Vinext、React 和 TypeScript。

## 本地运行

```sh
npm run dev -- --host 127.0.0.1
```

## 页面内容

- 个人介绍、教育背景与居住城市
- 支持分类、弹窗查看、键盘左右切换的生活相册
- 相处指南
- 点击拨号和复制号码

页面内容位于 `app/page.tsx`，样式位于 `app/globals.css`，图片位于 `public/photos/`。

照片与个人资料来自用户提供的飞书页面内《何丽江个人说明.pptx》。联系方式使用用户指定的 19526880781。网站不提交表单或收集访客数据。

部署身份保存在 `.openai/hosting.json`。发布使用 Sites 工作流，保留现有访问权限。

## GitHub Pages

运行 `npm run build:pages` 可导出静态网站到 `out/`，包含 GitHub 项目路径和全部图片。
在 GitHub 仓库 Settings → Pages 中将 Source 设为 GitHub Actions，推送 main 后由 `.github/workflows/pages.yml` 自动构建、部署。
GitHub Pages 的公开发布独立于原 Sites 网站的访问权限。
